"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
var mqtt_1 = require("mqtt");
var path_1 = require("path");
var http_1 = require("http");
var querystring = __importStar(require("querystring"));
var node_downloader_helper_1 = require("node-downloader-helper");
var fs_1 = require("fs");
var Messenger = /** @class */ (function () {
    function Messenger(win, config) {
        this.win = win;
        this.config = config;
        this._mqtt = null;
        this._initialized = false;
    }
    Messenger.prototype.initialize = function () {
        var _this = this;
        try {
            var mqttConfig = {
                host: this.config.mqtt.Host,
                port: this.config.mqtt.Port,
            };
            this._mqtt = mqtt_1.connect(mqttConfig);
            this._mqtt.subscribe(this.config.mqtt.VideoTopic);
            this._mqtt.subscribe('ProjectX/TS/Are/You/Alive');
            this._mqtt.on('message', function (topic, payload, packet) {
                if (topic === 'ProjectX/TS/Are/You/Alive') {
                    // this._mqtt.publish('ProjectX/TS/Are/You/Alive/ACK', 'yes');
                    _this.notify('Alive', 'Hi I am alive');
                    return;
                }
                if (topic === 'ProjectX/TS/Are/You/Alive/ACKONLY') {
                    _this._mqtt.publish('ProjectX/TS/Are/You/Alive/ACK', 'yes');
                }
                _this.processMessage(topic, payload);
            });
        }
        catch (error) {
            console.error(error);
        }
        this.initialized = true;
    };
    Messenger.prototype.reinitialize = function () {
        this.initialized = false;
        this.initialized = true;
    };
    Messenger.prototype.uninitialize = function () {
        this.initialized = false;
    };
    Messenger.prototype.processMessage = function (topic, payload) {
        var _this = this;
        if (topic === this.config.mqtt.VideoTopic) {
            var message_1 = JSON.parse(payload.toString());
            var videoFile = path_1.join(this.config.video.Directories[0], message_1.videoFileName);
            if (fs_1.existsSync(videoFile)) {
                fs_1.unlinkSync(videoFile);
                this.notify('Deleted', "Already existing " + message_1.videoFileName + " has been deleted");
            }
            var videoDl_1 = new node_downloader_helper_1.DownloaderHelper(message_1.videoUrl, this.config.video.Directories[0], { fileName: message_1.videoFileName });
            var imgDl = new node_downloader_helper_1.DownloaderHelper(message_1.imgUrl, this.config.video.Directories[0], { fileName: message_1.imgFileName });
            videoDl_1.start();
            imgDl.start();
            var statusInterval_1 = setInterval(function () {
                var stat = videoDl_1.getStats();
                _this._mqtt.publish(_this.config.mqtt.VideoTopic + "/PROGRESS", JSON.stringify({
                    downloaded: stat.downloaded / 1024 / 1024,
                    speed: stat.speed / 1024 / 1024,
                    remaining: (stat.total - stat.downloaded) / 1024 / 1024,
                    fileName: message_1.videoFileName,
                }));
            }, 5000);
            this.notify('Download started', message_1.videoFileName);
            videoDl_1.on('end', function () {
                clearInterval(statusInterval_1);
                var stats = videoDl_1.getStats();
                if (stats.total > stats.downloaded) {
                    _this.notify('Download Failed', message_1.videoFileName);
                }
                else {
                    _this.notify('Download completed', message_1.videoFileName);
                }
                _this.win.reload();
            });
            videoDl_1.on('error', function (err) {
                fs_1.unlinkSync(path_1.join(_this.config.video.Directories[0], message_1.videoFileName));
                fs_1.unlinkSync(path_1.join(_this.config.video.Directories[0], message_1.imgFileName));
                _this.notify('Download Failed', message_1.videoFileName + " was not able to download due to " + err.message);
            });
        }
    };
    Object.defineProperty(Messenger.prototype, "initialized", {
        get: function () {
            return this._initialized;
        },
        set: function (v) {
            this._initialized = v;
        },
        enumerable: true,
        configurable: true
    });
    Messenger.prototype.notify = function (title, message) {
        var postData = querystring.stringify({
            message: message,
            title: title,
            notifyMe: 'yes',
        });
        var options = {
            hostname: '35.244.47.236',
            port: 80,
            path: '/ThanosSnapUtility/Notify',
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Content-Length': Buffer.byteLength(postData),
            },
        };
        var req = http_1.request(options, function () { });
        req.on('error', function (e) {
            console.error("Problem with request: " + e.message);
        });
        req.write(postData);
        req.end();
    };
    return Messenger;
}());
exports.Messenger = Messenger;
//# sourceMappingURL=messenger.js.map
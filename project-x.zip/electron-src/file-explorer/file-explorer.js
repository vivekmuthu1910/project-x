"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __await = (this && this.__await) || function (v) { return this instanceof __await ? (this.v = v, this) : new __await(v); }
var __asyncGenerator = (this && this.__asyncGenerator) || function (thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
    function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
    function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
    function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
    function fulfill(value) { resume("next", value); }
    function reject(value) { resume("throw", value); }
    function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
};
var __asyncValues = (this && this.__asyncValues) || function (o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
};
Object.defineProperty(exports, "__esModule", { value: true });
var fs_1 = require("fs");
var path_1 = require("path");
var electron_1 = require("electron");
var child_process_1 = require("child_process");
var ping = require('ping');
var network = require('network');
var videoFileExts = ['.mp4', '.wmv', '.mkv', '.avi', '.flv', '.mov'];
function getStats(dir, files) {
    return __asyncGenerator(this, arguments, function getStats_1() {
        var i, file, stat, parseFilePath;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    i = 0;
                    _a.label = 1;
                case 1:
                    if (!(i < files.length)) return [3 /*break*/, 6];
                    file = files[i];
                    return [4 /*yield*/, __await(fs_1.promises.stat(path_1.join(dir, file)))];
                case 2:
                    stat = _a.sent();
                    parseFilePath = path_1.parse(file);
                    if (!videoFileExts.includes(parseFilePath.ext)) return [3 /*break*/, 5];
                    return [4 /*yield*/, __await({
                            name: file,
                            birthtime: stat.mtime,
                            size: stat.size,
                        })];
                case 3: return [4 /*yield*/, _a.sent()];
                case 4:
                    _a.sent();
                    _a.label = 5;
                case 5:
                    i++;
                    return [3 /*break*/, 1];
                case 6: return [2 /*return*/];
            }
        });
    });
}
var FileExplorer = /** @class */ (function () {
    function FileExplorer() {
        this._initialized = false;
    }
    FileExplorer.prototype.initialize = function () {
        var _this = this;
        electron_1.ipcMain
            .on('getVideos', function (event, dir, options) {
            _this.getAllVideoFiles(dir, options).then(function (val) {
                event.reply('getVideos', val);
            });
        })
            .on('getThumbnail', function (event, dir, file) {
            _this.getThumbnail(dir, file).then(function (val) {
                event.reply('getThumbnail', val);
            });
        })
            .on('playVideo', function (event, dir, file) {
            _this.playVideo(dir, file);
        });
        var gatewayIp = '';
        network.get_gateway_ip(function (err, obj) {
            if (err) {
                console.error(err);
            }
            else {
                gatewayIp = obj;
            }
        });
        var lastTimePingSuccess = 0;
        setInterval(function () { return __awaiter(_this, void 0, void 0, function () {
            var pingState, error_1;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 3]);
                        return [4 /*yield*/, ping.promise.probe(gatewayIp)];
                    case 1:
                        pingState = _a.sent();
                        if (!pingState.alive) {
                            if (Date.now() - lastTimePingSuccess > 1800000) {
                                child_process_1.exec('sudo shutdown now', function (err, stdout) {
                                    if (err) {
                                        console.error(err);
                                    }
                                });
                            }
                            child_process_1.exec('sudo pkill vlc', function (err, stdout) {
                                if (err) {
                                    console.error(err);
                                }
                            });
                        }
                        else {
                            lastTimePingSuccess = Date.now();
                        }
                        return [3 /*break*/, 3];
                    case 2:
                        error_1 = _a.sent();
                        return [3 /*break*/, 3];
                    case 3: return [2 /*return*/];
                }
            });
        }); }, 5000);
        this._initialized = true;
    };
    FileExplorer.prototype.getAllVideoFiles = function (dir, options) {
        var e_1, _a;
        return __awaiter(this, void 0, void 0, function () {
            var opts, subFilFol, fileStats, _b, _c, stat, e_1_1;
            return __generator(this, function (_d) {
                switch (_d.label) {
                    case 0:
                        opts = options || {
                            sortBy: 'time',
                            sortOrder: 'descending',
                        };
                        return [4 /*yield*/, fs_1.promises.readdir(dir)];
                    case 1:
                        subFilFol = _d.sent();
                        fileStats = [];
                        _d.label = 2;
                    case 2:
                        _d.trys.push([2, 7, 8, 13]);
                        _b = __asyncValues(getStats(dir, subFilFol));
                        _d.label = 3;
                    case 3: return [4 /*yield*/, _b.next()];
                    case 4:
                        if (!(_c = _d.sent(), !_c.done)) return [3 /*break*/, 6];
                        stat = _c.value;
                        fileStats.push(stat);
                        _d.label = 5;
                    case 5: return [3 /*break*/, 3];
                    case 6: return [3 /*break*/, 13];
                    case 7:
                        e_1_1 = _d.sent();
                        e_1 = { error: e_1_1 };
                        return [3 /*break*/, 13];
                    case 8:
                        _d.trys.push([8, , 11, 12]);
                        if (!(_c && !_c.done && (_a = _b.return))) return [3 /*break*/, 10];
                        return [4 /*yield*/, _a.call(_b)];
                    case 9:
                        _d.sent();
                        _d.label = 10;
                    case 10: return [3 /*break*/, 12];
                    case 11:
                        if (e_1) throw e_1.error;
                        return [7 /*endfinally*/];
                    case 12: return [7 /*endfinally*/];
                    case 13:
                        console.log(fileStats);
                        fileStats.sort(function (fileA, fileB) {
                            switch (opts.sortBy) {
                                case 'time':
                                    var fileATime = fileA.birthtime.getTime();
                                    var fileBTime = fileB.birthtime.getTime();
                                    return opts.sortOrder === 'ascending'
                                        ? fileATime - fileBTime
                                        : fileBTime - fileATime;
                                case 'size':
                                    return opts.sortOrder === 'ascending'
                                        ? fileA.size - fileB.size
                                        : fileB.size - fileA.size;
                                case 'name':
                                    return (opts.sortOrder === 'ascending'
                                        ? fileA.name < fileB.name
                                        : fileB.name < fileA.name)
                                        ? -1
                                        : 1;
                                default:
                                    return 0;
                            }
                        });
                        return [2 /*return*/, fileStats.map(function (val) { return val.name; })];
                }
            });
        });
    };
    FileExplorer.prototype.getThumbnail = function (dir, fileName) {
        return __awaiter(this, void 0, void 0, function () {
            var files, parsedPath, i, file;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, fs_1.promises.readdir(dir)];
                    case 1:
                        files = _a.sent();
                        parsedPath = path_1.parse(path_1.join(dir, fileName));
                        i = 0;
                        _a.label = 2;
                    case 2:
                        if (!(i < imageFileNames.length)) return [3 /*break*/, 5];
                        file = parsedPath.name + imageFileNames[i];
                        if (!files.includes(file)) return [3 /*break*/, 4];
                        return [4 /*yield*/, fs_1.promises.readFile(path_1.join(dir, file))];
                    case 3: return [2 /*return*/, (_a.sent()).toString('base64')];
                    case 4:
                        i++;
                        return [3 /*break*/, 2];
                    case 5: return [2 /*return*/, ''];
                }
            });
        });
    };
    FileExplorer.prototype.playVideo = function (dir, file) {
        var filePath = path_1.join(dir, file);
        var vlcCommand = "vlc -f \"" + filePath + "\"";
        child_process_1.exec(vlcCommand, function (err, stdout) {
            if (err) {
                console.error(err);
            }
        });
    };
    Object.defineProperty(FileExplorer.prototype, "initialized", {
        get: function () {
            return this._initialized;
        },
        set: function (v) {
            this._initialized = v;
        },
        enumerable: true,
        configurable: true
    });
    return FileExplorer;
}());
exports.FileExplorer = FileExplorer;
var imageFileNames = ['.jpg', '.png', '.jpeg'];
//# sourceMappingURL=file-explorer.js.map
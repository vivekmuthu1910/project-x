"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var os_1 = require("os");
var path_1 = require("path");
exports.video = {
    Directories: [path_1.join(os_1.homedir(), 'Videos')],
};
exports.mqtt = {
    Host: 'broker.hivemq.com',
    Port: 1883,
    TLS: false,
    VideoTopic: 'TN/ProjX/Dld/Vid',
};
//# sourceMappingURL=default-config.js.map